## Repo Creation for Groups of 2:

### Video instructions:


https://youtu.be/xqiNw5g5pqk

### Written instructions:

When setting up your repo please name your team as follows:

replace # with assignment number and your senecausernames as your seneca user names (without the @myseneca.ca part).
```
a# senecausername1 senecausername2
```
l
Thus, if you are creating a team for assignment 1 with team members were rkhojasteh and cleung

```
a1 rkhojasteh cleung
```


### At the classroom page:

* Team member 1 fills out the form to create the repo using the usernames of both members
* Team member 2 waits till after team member one has done the previous step and simply hits the join button for their team.

When completed you will have a common repository named a#g2-a#-yournames

* the # will be replaced with assignment number
* the duplicate of a# is needed to distinquish later assignment teams

### Repo Creation Links


* [A1 repo creation for teams of 2](https://classroom.github.com/a/0AeALBz6)
* [A2 repo creation for teams of 2](https://classroom.github.com/a/agXmwmsK)
