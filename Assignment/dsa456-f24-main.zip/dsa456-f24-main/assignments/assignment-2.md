# Assignment 2

## Due Dates:

* **Repo Creation Due: Nov. 13**
* **Due Date: Dec. 2**

### This assignment is worth 10% of your final grade.  

### Late penalties

#### Repo Creation

* Repo Creation:  -5 marks per day

#### Everything else:

* 10% per day
* **Assignment must be submitted no later than December 6**
* parts A and B must pass testing on github (Green check for each part in action tab). This will be the minimum requirement to get any marks for those parts of the assignment. It does not mean you will receive full marks.



## Assignment Objectives

In this assignment we will:

* Implement a hash table
* Create a game tree to implement game playing bots
* Extend the features of the game using data structures you learned

NOTE: **as this assignment is about implementing data structures, you are not allowed to make use of any Python libraries or use built-in python data structures and functions unless specified.  If you are not sure, please ask.  Any use a built-in libraries or functions without approval will result in having to redo the assignment with a grade penalty of -50%**

## Repo Creation - Due November 13

### Video instructions:

https://youtu.be/xqiNw5g5pqk

In this assignment you can choose to work in a group of two or three.  You have until 

to create a team of your choosing and create your repo.  After this date, students not in a team will be teamed up together by their profs**Working alone is not an option.**  In general we will try not to make adjustments to teams that you put together but there may be situations where we have no other ways of placing every student into a team without making changes to existing teams.  Our preference will always be to add someone to a team rather than breaking a team up and thus a three person team is very unlikely to be altered where as a two person team may end up with an additional person (but we will try to avoid this).

**Make sure you are clear how many people you are working with and who they are before using the appropriate link.  You will not be able to modify this once you have created the teams.  When you create your team, your team name will need to use every member's seneca user name**

If you do not have a team, try to find one by posting to course forums.  Be sure to include which section you are in as you cannot work with people not in your section.

**Make sure you use the correct link below!  It must match your team size.  Individual teams will receive a penalty.  READ The TEAM NAMING DETAILS CAREFULLY!**

* [Repo Creation for teams of 2](repo-creation-g2.md)
* [Repo Creation for teams of 3](repo-creation-g3.md)

You do not need to use same teams as assignment 1.  However, you must work in a group.

Every member of the team must submit a link to their assignment repo by the repo creation due date.  This means that not only must the repo be created, but every team member must have also joined the correct team.


## Work Divsion

* Every member of the team must contribute to one of the coding portions (parts A, B and C) of the assignment.  As there are 3 coding components, we expect each member to be the lead author in one of the 3 sections.  It doesn't mean that other team members can't help ... but the lead should be the main contributer to that part of the assignment.  If you are chosing not to do part B and you have 3 people on your team, contributions from at least 2 teammembers for part C.
* Every member is expected to push their own code.
  * **it is NOT ok to use email or have just one person commit all the code. git/github is a professional tool that employers expect our graduates to know how to use, so learn it now.  If you aren't sure, check out the git tutorial listed in the resources section in course repo.**
* Team members that do not commit code for one of the coding components will not receive any credit for the assignment.  They will be removed from the group and will need to redo the entire assignment with late penalties.

## Part A - Hash Tables (10 marks)


In this part of the assignment you will implement a class called HashTable which implements a hash table.  

When doing this portion of the assignment you can use:

* python list for the main table (but NOT the chains if you are doing chaining)
* python hash() function - don't write your own
* Your linked list from part A (if you wish to create a chaining hash table)

You may use either chaining or linear probing as your collision resolution method.  The exact method and details of implementation (such as using tombstones or not if you choose linear probing) is up to you.


### Member functions


---

```python
	def __init__(self, capacity=32):
```
The initializer for the table defaults the initial table capacity to 32.  It creates a list with capacity elements all initialized to None.

---


```python
	def insert(self, key, value):
```
This function adds a new key-value pair into the table. If a record with matching key already exists in the table, the function does not add the new key-value pair and returns False. Otherwise, function adds the new key-value pair into the table and returns True.  When an insertion causes the HashTable's load factor to exceed 0.7, the list used to store the table must be resized.  Resizing must still allow every existing record to be found.



---

```python
	def modify(self, key, value):
```
This function modifies an existing key-value pair into the table. If no record with matching key exists in the table, the function does nothing and returns False. Otherwise, function changes the existing value into the one passed into the function and returns True

---

```python
	def remove(self, key):
```

This function removes the key-value pair with the matching key.  If no record with matching key exists in the table, the function does nothing and returns False.  Otherwise, record with matching key is removed and returns True

---

```python
	def search(self, key):
```

This function returns the value of the record with the matching key.  If no reocrd with matching key exists in the table, function returns None

---

```python
	def capacity(self):
```
This function returns the number of spots in the table.  This consists of spots available in the table.  

---

```python
	def __len__(self):
```

This function returns the number of Records stored in the table.

---


## Part B - A Game tree based bot  (10 marks)


In this part of the assignment you will implement a bot that will play a simple board game by performing look-ahead's using a game treee.

For this part of the assignment you will need to do the following:

* Write an Evaluation Function.
* Create a Game tree

### The rules of the game.

This game is a 2D board game.  Initially player 1 has a gem in the top left corner and player 2 has a gem in the bottom right corner. Players take turns adding one gem per turn to the board.  A gem can be added to any empty square or any square where the player has at least one gem.  If the number of gems in a square reaches the number of neighbours for the cell, the gems overflow into its neighbours, increasing the number of gems and changing the colour of gems to that player's colour (follows the rules of the overflow() function from assignment 1.)

The game ends if every single gem on the board is the same colour.  The player represented by that colour is the winner of the game.

Your repo includes an implementation of the game.  You will need to run this locally as codespaces won't properly support pygames.

To run the game use the command:

```
python game.py
```

Note that the current AI player is just a stub.  It doesn't even check if the move it is making is valid.  The first player always places a piece into top left corner.  The second player always puts a piece in the bottom right corner.  It is up to you to implement an actual AI bot for the game.

If the AI player makes an invalid move, the game will end and the other player will automatically win the game. 



### Write an Evaluation Function

```python
def evaluate_board(board, player)
```

* **board** - The board is a 2D grid with numbers.
	- 0 indicates that the cell is empty
	- the absolute value of a non-zero number indicates the number pieces in the corresponding cell
	- the sign indicates which player's pieces are in the cell.  Positive numbers are player 1.  Negative numbers are player 2
* **player** - This number is either +1 or -1.  A +1 means we are evaluating the board for player 1.  A -1 indicates the function is evaluating the board for player 2.

Given a board and the player you are evaluating the board for, this function returns a score for the board.  Ensure that the score for a winning board is higher than any estimate for a non-winning board.  Also ensure that a score for a losing board is lower than any non-losing board.  Non-winning is just any board that isn't in a winning state for the player.  It does not mean the player has lost.. just hasn't won.  Similarly a non-losing board is just a board in a state where player hasn't lost.  The exact algorithm for this is entirely up to you as long as it follows the rule for scoring non-winning/non-losing boards.

### Implement a Game Tree

A game tree is a data structure that allows you to search through a series of possible next moves players can make in a game.  This data structure allows you to consider not only what you can do but what your opponent can do based on what you did, then you can choose what to do based on what your opponent did and so on...


For games with a small number of possible states, it is possible to generate all possible moves to a terminal state.  That is a state where the game has ended because someone has won or a the game has reached some sort of tied state where no one else can make any more moves.

For example, this is possible in a game like tic-tac-toe as there are less than 9! = 362880 nodes in a game tree starting from an empty board.  Thus tic-tac toe is considered to be solved.. the computer can always play to a tie game if the opponent makes no mistakes

For games that have more possible states, where it is not possible to generate all moves to a terminal state, game trees are typically created to a certain height.  The boards at the leafs are evaluated using an evaluation function that tries to estimate a score for a given board.  A minimax function is then applied to the tree in order to find the best move


### Game Tree

#### Nodes

A game tree node has a set of pointers its children node. represents what moves it can make. This Node class must be internal to your GameTree Class

```python
__init__(board,depth, player, tree_height = 4)
```
When a node is instantiated, it is passed 
* a 2D array representing the board for the node, 
* the depth of this node
* the height of the game tree
* the player (1 or -1) the tree is being created for.  
This function initializes the node.


***

#### GameTree Class

```python
__init__(board, player, tree_height = 4)
```

This function initializes the GameTree Object.  It is passed:

* board - the 2D array representing the board of the game in its current state
* tree_height - the maximum height of the tree to be generated
* player - the player the tree is being created for


The init function will build the game tree to a height of tree_height

In the construction of the game tree, you will create children for each node representing the placement of a piece.  Depending on the level of the node, the player placing the piece will be different.  The root represents the board in the current state, all nodes at level 1 (root's children) represent the placement of the player's piece to the original board. After placing the piece and performing the overflow routine as needed, you will get a new board for each placed piece.  that new board form the boards for the nodes of level 1.  After the player makes a move, the opponent makes a move. Thus, each node in level 2 is formed by the opponent placing a piece onto the board in its parent node.  At level 3, we go back to the player's move and so on.

##### Scoring each node

Your tree will have leaf's due to various conditions:
	a) the board for the node is in a terminal state (someone has won)
	b) the node has reached its maximum depth (tree_height-1).  

For any leaf node, the board is evaluated using the evaluation function.

For any inner node, the minimax algorithm determines the score for the node.

minimax is based on the following:

* You want the best possible board for yourself
* Your opponent wants the worst for you

Thus, if you are making a move, you want the best possible move you can make.  However, if your opponent is making a choice on what move to make, they will want the worst possible move for you.

To score an inner node, choose the best or worst score in the children nodes depending on who is making the move. A node at an even level is scored as the max of the children's scores while the node at an odd level is scored as the min of the children's scores.

Since you need to score nodes based result's of children, it is necessary to score the nodes in a depth first manner (ie you can't find the score of a node unless you know the scores of all the children)

You can either create the entire tree, then perform a depth first traversal to score each node, or you can score the nodes as you create the tree.  The choice is yours

***

```python
def get_move(self)
```
This function gets (row,col) which is the position of the choice from the tree.

***

```python
def clear_tree(self)
```
This function destroys the game tree by unlinking all nodes in order to allow the garbage collector to work on clearing the memory.




#### Ways to make your bots better

NOTE.  Your grade is not based on how good your bots perform!!  Even if they are terrible at the game you can still get top marks.  They simply need to implement a game tree and evaluation function to spec.  See rubric on grading.

- a good evaluation that scores boards accurately is useful
- a fast evaluation function is useful (you can create taller trees if your function is faster)
- with game trees, the key to making better game trees is actually to have taller game trees.  A taller game tree is better than a good evaluation function.  One way to create taller trees is to prune.  If you are interested in this, check out the idea of alpha-beta prunning

## Part C: Game Improvements (10 marks)

This part of the assignment is open ended.  There are different features that you can add to make this game better.  Exactly what you implement is up to you!  The only rule is the basic game must remain the same.  Note, the feature added needs to be coding based.. so changing out the artwork for something that looks better is not considered a valid extra feature.  Here are some suggestions to get you started.. but you are free to use your imagination to add more.

* Create an "undo" last move button for any human players (AI bots shouldn't be allowed to undo) as long as they haven't lost.  This undo reverts the game to a state before that human player's last move.
* Add Animations... the gems currently just "appear" when they overflow.. you can animate the movement
* Add UI elements to increase/decrease the smartness of the bots (the taller the game tree the smarter the bot)


**This is only a very very limited set of ideas.  You are free to be creative and add others**

If you need a Stack, Dequeue, Queue, HashTable, LinkedList to implement your idea, you must make use of the data structure you wrote earlier in the class.  If you need other data structures, you can use the built in python ones for this part of the assignment.

This part of the assignment has no testers as we don't know what you will implement.  Thus, aside from pushing an updated version of game.py to the repo, you will need to also provide the following:

* A video with voice over the video must:
	1. demonstrate the feature(s) you added
	2. explain how you implemented the features
	3. especially speak to the data structures you used and how they helped in the implementation.
	4. This video should be around 2 to 3 minutes.  Any video over 5 minutes long will receive a reduced grade.  Be succint in your explanation.

* Submit the video using Seneca's one-drive and share it so that anyone with link can view the video.  Make sure that the access is properly given as an inability to view the video can result in a reduced grade
* Alternative you can can put it on youtube as an unlisted video and submit the link for that.


See rubric for grading



## Part D - Video Reflection: (5 marks)


Create a 2 minute max video, explaining what YOU did for the coding portion of the assignment.  Not your partners.. just you.  In the video be sure to include the following (based on what you were responsibile for)

* if you are responsible for the hashtable, which collision resolution method you chose to implement and what you learned about that particular hash table implementation.
* if you were responsible for the game tree and evaluation functions, describe your evaluation function and why you scored the board that way, explain what you did.
* If you were responsible for the game improvements explain what features you chose to implement.  As part C video already go over the data structure you used, this reflection video should include thoughts about why you chose the data structures you chose (as opposed to what data structures you chose) and details on challenges you faced during implementation and so on.



**The video should be around 1 to 2 min.  Marks will be deducted if it is more than 3 minutes.  You need to be succinct**


## Submitting your assignment


* Push your code into your repo and ensure it passes all the testings by checking the actions tab.  If your code doesn't pass testing, your assignment is considered incomplete. You must complete the assignments to pass DSA456

* For the video, you can either use stream over sharepoint or an unlisted youtube video (make sure to get a proper sharing link and submit that for part D).



## Rubrics:

Don't forget to check the style guide


This sections describes how your assignment will be graded:


### Coding Rubric:

| Criteria | Level 0 | Level 1 | Level 2 | Level 3 | Level 4 |
|---|---|---|---|---|---|
| **Documentation - 20%** - Documentation is about Intention.  "This function is suppose to do" X.  It doesn't state HOW. "we loop, then there is an if, then ..." - this is an example of what not to do.  It doesn't repeat code.  For each function ensure that it describe what it does (at a high level), what it accepts as arguments and any sort of restrictions (number must be positive for example) and what the function should return under what condition (returns True if found for example) |Almost no documentation of any type |only a few functions got documented and documentation tends to be code description as opposed to code intention. | many function documentation missing or severe lack of details for function description or documentation is done only at code level (within the code) and not as an overall intention| a few functions documentation missing. or function description comments lack some detail.  Over documentation.  documenting every line of code is not a good... let the code speak | For all functions state what parameters are (and any limitations, what return value is, what it does. |
| **Code Styling - 10%** Consistent styling is key.  This category describes things like indentation, consistent naming strategies, good variable names, not adding public member functions etc. | more than 5 cases of inconsistent or bad styling | 3 to 5 cases of inconsistent  or bad styling | 2 to 3 cases of inconsistent or bad styling functions | 1 case of inconsistent  or bad styling | Consistency is key. same variable name styling, same data member styling, correct and consistent indentation, good variable names | 
|**Correctness and Completeness of Code - 35%**.  This category generally describes errors in logic or missing functionality that may occur only in some cases.  This category also includes using things you are not suppose to use or not following specifications correctly | 4 or more errors | 3 errors | 2 errors - using something you are not suppose to use will count at a minimum as two errors as it is a spec violation | 1 errors | all functions completed and correct |
| **Efficiency - 35%** - Anything that is completely off from optimal run time will always count as an instance of inefficiency.. thus if runtime can be O(n) and your code is written to O(n^2)  These count as a major instance. Writing unnecessary code will also be counted as inefficient even if runtime is same as the optimal run time, these are considered minor. 2 level deduction for major instance, 1 level for minor instance| some combination of multiple major/minor incidences of efficiency | 3 minor instance of inefficiency or 1 major and 1 minor instance | 2 instance of inefficiency or 1 major instance of inefficiency| 1 minor instance of inefficiency | Function is as efficient as possible |

### Part C Rubric

 Criteria | Level 0 | Level 1 | Level 2 | Level 3 | Level 4 |
|---|---|---|---|---|---|
| Part C | The feature presented is unclear as to what it does or how it was implemented... it is unclear if that it even works from video or program does not actually run | There is at least one clear feature presented but the discussion of how it is implemented is unclear or wrong | There is at least one feature that is clearly presented and the explanation about how the feature is implemented at a high level but lacks details OR a demonstration of multiple features with clear explanations that has exceeded the maximum length of 5 minutes | More than one feature is implemented with a good description of the implementation | More than one feature is implemented with an excellent indepth but succinct description of the implementation|


### Reflection Rubric

 Criteria | Level 0 | Level 1 | Level 2 | Level 3 | Level 4 |
|---|---|---|---|---|---|
| Reflection | No reflection submitted | Video reflection does not have any details, statements made can apply to anything or statements made does not match the work that is submitted | Video is overly long (over 2min 30 sec) or Video reflection lacks depth, either the statements made are vague or simply a line by line reading of the code without explanation of the intention of that code | Video reflection shows some depth with some descriptions.  It does not go far beyond the basic requirements | A video reflection with clear thought that shows depth and understanding of the work|



