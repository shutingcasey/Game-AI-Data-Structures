### Video instructions:


https://youtu.be/xqiNw5g5pqk

### Written instructions:

When setting up your repo please name your team as follows:

replace # with assignment number and your senecausernames as your seneca use r names (without the @myseneca.ca part).
```
a# senecausername1 senecausername2 senecausername3
```

Thus, if you are creating a team for assignment 1 with team members were dsharma, ramjoun and nismat

```
a1 dsharma ramjoun nismat
```


## At the classroom page:

* Team member one fills out the form to create the repo using the usernames of both members
* Team member two and three waits till after team member one has done the previous step and simply hits the join button for their team.

When completed you will have a common repository named a#g3-a#-yournames:

  * the # will be replaced with assignment number
  * the duplicate of a# is needed to distinquish later assignment teams

## Repo Creation Links

* A1 [repo creation for teams of 3](https://classroom.github.com/a/QtNCWLHD)
* A2 [repo creation for teams of 3](https://classroom.github.com/a/OiFsUj9m)
