DSA456 - Data Structures and Algorithms - Fall 2024 - all sections


Note this addenda is a general version of the addenda posted for your section.  Due to holidays and such, the timeline below may be slightly shifted.  Please see the addenda for your section specifically


## Assessment Summary

* Assignment (2 at 10%): 20%
* Quizzes: 10% (Top 5 of 6 X 2% each)
* Labs: 10% (Top 5 of 6 X 2% each)
* Test 1: 30%
* Final Test: 30%


## Course Policy

In order to pass DSA456 you must:

* Achieve a grade of 50% or better on the weighted average of the midterm and final test OR achieve 50% of better on final test
* Achieve a grade of 50% or better overall

## Grading Policy: 

http://www.senecacollege.ca/about/policies/grading-policy.html)

## Academic Policy:

http://www.senecacollege.ca/about/policies/academics-and-student-services.html


**PLEASE RETAIN THIS DOCUMENT FOR FUTURE EDUCATIONAL AND/OR EMPLOYMENT USE.**


## Subject notes

https://seneca-ictoer.github.io/data-structures-and-algorithms/

Note that the above notes are currently only available electronically (no offline mode yet).

## Textbook (Optional - for Reference)

There are lots of data structures and algorithms texts around.  These are two we are recommending

Data Structures & Algorithms Analysis in C++, 4th edition, Mark Allen Weiss, ISBN 013284737X Great book but it can be a bit hard to read because there are some implementational details that are implied, and it is structured more toward analysis. Not the easiest read but a great reference. Unfortunately, this book does not have an electronic version available through the library.  There is a copy in the library but it's a hard copy.

Introduction to Algorithms, Third Edition,  Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, and Clifford Stein, Ebook ISBN: 9780262270830
This book does not have language-specific implementations but is very good for the theoretical components.  It is also available electronically.
https://senecacollege-primo.hosted.exlibrisgroup.com/permalink/f/1e177uh/01SENC_ALMA5143611310003226



## Tentative Timeline

All readings are from the subject notes: https://seneca-ictoer.github.io/data-structures-and-algorithms/
Unless otherwise stated, the links below are linked to the start of the chapter of notes you should be reading.  The reading is up to the end of the chapter of notes,  not just the intro page.  

Note that your section of the course may shift topics due to events like holidays.  This is simply a general listing of the topics in the order that it will be taught.



| Week       | Topics and Reading                                                                                                                                                                                                                                                                            | 
|------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| week 1     | [Introduction](https://seneca-ictoer.github.io/data-structures-and-algorithms/), [Intro to Python](https://seneca-ictoer.github.io/data-structures-and-algorithms/A-Python/intro-to-python)                                                                                                   | 
| week 2     | [Analysis of Algorithms](https://seneca-ictoer.github.io/data-structures-and-algorithms/B-Algorithms-Analysis/intro-to-analysis), [Asymptotic Notation](https://seneca-ictoer.github.io/data-structures-and-algorithms/B-Algorithms-Analysis/asymptotic-notation)                             | 
| week 3     | [Recursion](https://seneca-ictoer.github.io/data-structures-and-algorithms/C-Recursion/intro-to-recursion), [Searching, and Sorting]()                                                                                                                                                        |
| week 4     | [Searching and Sorting](https://seneca-ictoer.github.io/data-structures-and-algorithms/D-Searching-And-Sorting/intro-to-search-and-sort),  [Lists](https://seneca-ictoer.github.io/data-structures-and-algorithms/E-Lists/intro-to-lists),                                                    | 
| week 5     | [Lists](https://seneca-ictoer.github.io/data-structures-and-algorithms/E-Lists/intro-to-lists),[Stacks, and Queues](https://seneca-ictoer.github.io/data-structures-and-algorithms/E-Lists/stacks-and-queues)                                                                                 | 
| week 6     | [Tables](https://seneca-ictoer.github.io/data-structures-and-algorithms/F-Tables/intro-to-tables)                                                                                                                                                                                             | 
| week 7     | Cleanup, Review and, Test 1                                                                                                                                                                                                                                                                   | 
| break week | ...                                                                                                                                                                                                                                                                                           | ...                                   |... |... |
| week 8     | [Graphs](https://seneca-ictoer.github.io/data-structures-and-algorithms/G-Graphs/intro-to-graphs)                                                                                                                                                                                             |  
| week 9     | [Graphs](https://seneca-ictoer.github.io/data-structures-and-algorithms/G-Graphs/intro-to-graphs),[Trees](https://seneca-ictoer.github.io/data-structures-and-algorithms/H-Trees/intro-to-trees)                                                                                              | 
| week 10    | [Heaps, Heapsort](https://seneca-ictoer.github.io/data-structures-and-algorithms/I-Heaps/intro-to-heaps)                                                                                                                                                                                      | 
| week 11    | [Binary search trees](https://seneca-ictoer.github.io/data-structures-and-algorithms/J-Binary-Search-Trees/intro-to-bst)                                                                                                                                                                      |
| week 12    | [Augmented data structures](https://seneca-ictoer.github.io/data-structures-and-algorithms/K-Augmented-Data-Structures/intro-to-augmented-data-structures)                                                                                                                                    | 
| week 13    | [Augmented data structures](https://seneca-ictoer.github.io/data-structures-and-algorithms/K-Augmented-Data-Structures/intro-to-augmented-data-structures),[Complexity theory](https://seneca-ictoer.github.io/data-structures-and-algorithms/M-Complexity-Theory/intro-to-complexity-theory) | 
| week 14    |  Final Test (See your section's specific addenda for actual date)    | 

## Quizzes

Quizzes are mini-tests.  They will take approximately 20 minutes to complete.  Each quiz is worth 2%.  You must write the quizzes at scheduled time as there is no makeup quiz.  There are 6 quizzes in total and your top 5 quiz marks will count towards your final grade.


## Labs

Labs are short programming, analysis, or long answer problems. Labs are meant to reinforce ideas and concepts covered. They typically should not require more than **two to four hours of work each**. Missed labs get a grade of 0. Everyone will be allowed to miss one lab without penalty.  Some labs have required in person participation. Please read each lab carefully to determine if this is required. The lowest lab grade is always dropped. You do not need to ask permission or let us know. It will be automatic.

Labs have a grade of 0, 1, and 2. If they are correctly completed and submitted before the due date, the grade is 2. If there are significant errors and or missing components but the bulk of it is done, you may get a mark of 1. Note that for any lab that has a coding component, **a test verification is a MINIMUM requirement for any consideration of partial marks** If they are not submitted by the due date, the grade for the lab will be 0.

For analysis questions, most of your answers must be correct. The key is that you have tried to do it. Even if it is not correct, we are willing to help guide you through it. However, if you don't show your work, and there are simply random formulas that do not show your process, then you will get zero.

See the rubric including in each lab for details on how a lab is graded.



## Assignments

Assignments are more complex assessements that are meant to develop deeper, professional skills.  They are graded on the quality of the work (ie completion is a minimum requirement only, see assignment grading section). The quality of a piece of work includes many different aspects but can include:

* Documentation
* Consistent coding style and practices
* Correct Memory Usage
* Correctness of Code for edge cases
* Efficiency
* Correct mathematical and analytical statements for analysis
* Thorough, complete, and correct answers to the reflection question

An assignment will take approximately 10 to 20 hours to complete.  They are not meant to be done the night before they are due.  Assignments are designed to be completed in a group.  Every member of the team must complete 


### Assignment Completion

Your assignment is only considered completed if every task listed under assignment completion for that assignment is done and in a manner that does not violate the spirit of the assignment.  Completion and grading are separate matters.  Completion is the minimum requirement to receiving a non-zero grade.

Note that meeting the minimum completion standard does not mean that you will get full marks. It only means that the assignment has met a minimum level of completeness for some marks.


### Assignment Grading

In earlier programming courses, the focus was on solving a problem and writing code that was working, well structured and well documented.  Those requirements are still in place for DSA456. However, a large part of this course is about the analysis of source code. As such, simply making the code "work" and having well-structured, documented code will not be good enough for full marks on an assignment. Your code must not only work to spec but also have an efficient implementation.  This will apply to all programs for this course. If your solution is not algorithmically efficient, marks will be deducted. You may even need to resubmit your program if it is very far off from the optimal efficiency.  You will need to think through your code in order to get full marks for your work.


## Assignment/Lab Submission

Your assignments and labs will be submitted through your GitHub repository. There will be repositories created for your labs and assignments. They will be clearly split. Follow the instructions in lab 0 to learn how to create repositories.  These repositories are private and will contain starter files for you to do your assignment/lab.  You and your professor see exactly the same repository, thus you can be assured that what you see is exactly what your prof sees.

Each lab/assignment will have specific instructions on submitting the assignment. Failure to follow submission instructions may result in a penalty


## Missed Test Policy

If you miss a test, your mark for that test is automatically 0. However, if there was a valid and well-documented reason for your missing the test, we may make considerations for those events and provide a means for you to get the grade of your missed test mark.


## Copyright and Reposting of Course material


Most of the materials posted in this course are protected by copyright. It is a violation of Canada's Copyright Act and Seneca's Copyright Policy to share, post, and/or upload course material in part or in whole without the permission of the copyright owner. This includes posting materials to third-party file-sharing sites such as assignment-sharing or homework help sites. Course material includes teaching material, assignment questions, tests, and presentations created by faculty, other members of the Seneca community, or other copyright owners. 

It is also prohibited to reproduce or post to a third-party commercial website work that is either your own work or the work of someone else, including (but not limited to) assignments, tests, exams, group work projects, etc. This explicit or implied intent to help others may constitute a violation of Seneca’s Academic Integrity Policy and potentially involve such violations as cheating, plagiarism, contract cheating, etc.


