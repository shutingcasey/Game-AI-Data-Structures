# Documentation and Style Guide

Proper styling and documentation is important and makes a difference in how well your program reads. As you are training to be professionals, you should develop a proper styling for your programs. These are guidelines for this course.
Documentation

Proper documentation is about quality not quantity. Documenting every line of code is not useful. However, you need to provide good documentation. Here are some general do's and dont's for documentation

### DO's :

* DO state intentions
```c
  //this function accepts an integer and calculate's the n'th fibonacci value
	//in the fibonacci sequence.  it returns this number.
	int fib(int n);		
```
* DO state things that go beyond names (like units):
```c
	double height;  //the height of the triangle in cm
```
* DO state for each function what it accepts, what it returns and what it does (at a high level), special cases, etc.
```c
  //this function inserts a new node with data into the list before the node referred to by loc.  
  //function returns iterator to the newly inserted node.  
  //loc is allowed be end()
  iterator insert(iterator loc, const T& data); 
```

### Dont's:

* Don't state the obvious
```c
	 int x;                   //x is an integer
	 int fib(int n);          //fib is a function, it accepts an integer
```
* Don't write line by line comments that mirrors the code... documentation is about intention. You want to state why are you doing something instead of what you are doing. The what should be obvious from the code. The intention is not always obvious and needs documentation.

```c
	for(int i=0;i<10;i++){ //this is a for loop, it runs 10 times
		  x = x+1;           //add 1 to x
		  y = y-1;           //subtract 1 from y
	} 
```

## Style

* Indentation: each block of code requires a level of indentation:
```c
void function (....){
	for(....){
		if(....){
			while(...){

			}
		}
	}
}
```
* Use meaningful variable names:

  * don't use single letter variable names except for something like a loop counter.
  * don't use the variable name flag. This is as meaningless as x. especially bad if you have flag1, flag2, etc.
  * Camel case variable names is preferred in C/C++ (lower case first letter, and lower case in general, upper case first letter of each word other than first)
    ```c
    int thisIsAVariable = 0;
    char theName = 'a';
    ```
  * snake case is preferred in python
    ```python
    this_is_a_variable = 0
    the_name = "a"
    ```
  * As much as possible, declare only one variable per line. Only exception is if two variables are closely related.
  * Consistency is key to good styling
    * Good styling is about consistency. However you choose to do the things that are not spelled out, is up to you. However, you need to be consistent within your own styling.

### Brackets

Example: Do beginning curly brackets go at end of line or next line?
```c
//end of line style
for(...){
 ...
}

//new line style
for(...)
{
...
}
```
Which one do you use? There are languages where there is actually syntactic reasons for one over another. However, for this course do whichever you like. Most important thing is that it isn't different for every block of code... pick one and stick with it.

### Variable Names

* Variable names need consistent styling. whatever you decide is fine, but you need to be consistent.
* variable name conventions: camelCase or snake_case?
* extra chars for data members: _datamember or datamember_ or  datamember or mdatamember?
Pick one a styling, and stick with it throughout the program


### Tabs and Spacing

    * tab size: 2, 4 or 8? pick one... don't change it halfway through program
    * tabs vs spaces: pick one, stick with it. No matter what, make sure its correct and consistent.


