# Lab 4

This assessment contains materials that may be subject to copyright and other intellectual property rights. 

Modification, distribution or reposting of this document is strictly prohibited. Learners found reposting this document or its solution anywhere will be subject to the college’s Academic Integrity policy.

## Due: In class at the end of your lab period when this lab is assigned

## Objectives:

In this lab you will look at how kruskal's and prim's algorithm works.

Use the following graph for both Kruskal's and Prim's

![lab4graph)](lab4.png)

## Setup

- Find a partner or two
- On the sheet of paper given to you write your name
- **Each person must submit their own sheet**
- label one side of paper as Kruskal's and the other side as Prim's
- show result of lab on appropriate side

## Submitting your lab

In order to get a mark for this lab, you must submit:

* the lab sheet that is given to you at start of the lab



## Lab Rubric:

| Criteria       | Poor - 0 mark     | Fair - 1 marks                                                                                                                     | Good - 2 marks                                                              |
| -------------- | ----------------- | ------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------- |
| Lab Completion | Arrived in class to do lab more than 30 min late or  did not attend | Arrived in class to do lab more than 10 min late but less than 30 min late and/or Missing discussion | Arrived in class within the first 10 min of class and submitted work has a thorough discussion |
