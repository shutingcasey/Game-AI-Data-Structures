# Lab 2

This assessment contains materials that may be subject to copyright and other intellectual property rights. 

Modification, distribution or reposting of this document is strictly prohibited. Learners found reposting this document or its solution anywhere will be subject to the college’s Academic Integrity policy.


## Due: Sunday Sept 22, 2024

## Objectives:

-   Learn how to perform analysis
-   Learn about the relationships between results of an analysis and wall-clock results.

## Setup


All files needed for this lab were created by doing the first task in [lab 0](lab-00.md).  If you didn't do lab 0, do the first task to create your lab repository.

Unless otherwise stated, all writing goes into the file lab2.md

## Part A Analysis


Follow this guide on how to perform an analysis:

https://seneca-ictoer.github.io/data-structures-and-algorithms/B-Algorithms-Analysis/how-to-do-an-analysis

Perform an analysis of the following functions.  

### function 1:

Analyze the following function with respect to number

```python
def function1(number):
	total = 0

	for i in range(number):
		x = i + 1
		total += x * x

	return total
```

### function 2:

Analyze the following function with respect to number

```python
def function2(number):
	return (number * (number + 1) * (2 * number + 1)) // 6
```

### function 3:

Analyze the following with respect to the length of the list.  Note that the function call len() which returns the length of the list is constant (O(1)) with respect to the length of the list.
```python
def function3(list):
	n = len(list)
	for i in range(n - 1):
		for j in range(n - 1 - i):
			if list[j] > list[j+1]:
				tmp = list[j]
				list[j] = list[j+1]
				list[j + 1] = tmp
```

### function 4:

Analyze the following function with respect to number

```python
def function4(number):
	total = 1
	for i in range(1, number):
		total *= i + 1
	return total
```

## Part B In-Class Discussion

In your repo, you will find lab2.py which contains 3 functions (that all do the same thing... but it doesn't matter for the discussion below).



* Form a small group of 2 or 3 members.
* Split up the functions and have each member analyze at least one of the functions.  Teams of two will have to figure out who analyzes the third function.
* After you analyze the function, use the lab2_timer.py program to time the 3 functions at various data sizes (you can change this in line 10 of lab2_timer.py)
* Create a graph (scatter plot with curve in excel) of the 3 functions at various data sizes.  Use a minimum of 10 different data sizes in your plot.  Use data size values that are large enough for the timing info to be meaningful (hint: start with x, then use 2x, 3x, 4x etc...)
    * you can either edit the file multiple times or you can edit the file and add a loop to get the data that you need...if you do it correctly, you can generate a comma separate file that can be directly loaded into excel for the next part.
* For each function's curve, compare the curve against the curves here:
https://seneca-ictoer.github.io/data-structures-and-algorithms/B-Algorithms-Analysis/growthrates
* Note which curve each function best matches
* this may also be useful: https://wiki.python.org/moin/TimeComplexity
  
### Based on the work above, do the following/answer the questions:

All work is to be placed in lab2.md

1. Place your analysis of the 3 functions into lab2.md
2. Get an image of the graph and add it to lab2.md (if you don't remember how, see lab0)
3. Did the result of your analysis match that of the timed curve?
4. For each curve that did not match, discuss the analysis with your team and find out where things might have gone wrong (was it the way the timing was done?  was it the analysis itself?)
5.  Was there anything that surprised you about the result?  Did a piece of code turn out to be faster/slower than you expected?


## Submitting your lab

* push an updated version of lab2.md and any other relevant files into the lab2 folder of your lab repository

## Lab Rubric:

* For part A to be completed, a complete analysis (full 5 steps) for every function must be completed.  A simple conclusion without showing how the results were arrived at will be considered incomplete.

* For part B to be completed, you must arrive in class within 15 minutes of the start of your lab period and participate in the class discussion and all 5 of tasks/answers are added to lab2.md


| Criteria       | Poor - 0 mark     | Fair - 0.5 marks                                                                                                                     | Good - 1 marks                                                              |
| -------------- | ----------------- | ------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------- |
| Lab Completion | Part A incomplete and part B are both incomplete | part A or Part B is incomplete | both part A and part B is completed |
