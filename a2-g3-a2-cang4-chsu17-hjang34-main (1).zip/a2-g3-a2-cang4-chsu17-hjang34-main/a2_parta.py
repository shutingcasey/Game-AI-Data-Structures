#    Main Author(s): Hyeri Jang
#    Main Reviewer(s): Christine Ang, Shu-Ting Hsu


class HashTable:

	# You cannot change the function prototypes below.  Other than that
	# how you implement the class is your choice as long as it is a hash table

	# The constructor that initializes the hash table
	# Parameters:
	#	cap: hash table's initial capacity (default: 32)
	def __init__(self, cap=32):
		self.cap = cap
		self.table = [None] * cap
		self.size = 0
		self.tombstone = (None, "TOMBSTONE") # Marker

	# This function that inserts new key-value pair into hash table
	# Parameters:
	#	key: the key to insert
	#	value: the value to insert
	# Returns:
	#	- True: if the insertion is successful
	#	- Faluse: if the key already exists in the hash table
	def insert(self,key, value):
		index = hash(key) % self.cap 
		# Tombstone is not yet found
		tombstone_index = -1

		while self.table[index] is not None:
			if self.table[index] == self.tombstone:
				# Record the first tombstone index to reuse
				if tombstone_index == -1:
					tombstone_index = index
			elif self.table[index][0] == key:
				# Key already exists
				return False
			index = (index + 1) % self.cap
		
		# Use tombstone index if available
		if tombstone_index != -1:
			index = tombstone_index

		self.table[index] = (key, value)
		self.size += 1

		# Resize the table if load factor to exceed 0.7
		if self.size > 0.7 * self.cap:
			new_capacity = self.cap * 2
			new_table = [None] * new_capacity

			# Rehash the elements
			for element in self.table:
				if element is not None and element != self.tombstone: 
					rehash_key, rehash_value = element
					new_index = hash(rehash_key) % new_capacity

					while new_table[new_index] is not None:
						new_index = (new_index + 1) % new_capacity
					new_table[new_index] = (rehash_key, rehash_value)

			# Update the table and capacity
			self.cap = new_capacity
			self.table = new_table
		
		return True

	# This function updates the value with a given key
	# - Parameters:
	#	key: the key to update
	#	value: the new value to associate with the key
	# - Returns:
	#	- True: If the key exists and is updated successfully
	#	- False: If the key does not exists
	def modify(self, key, value):
		index = hash(key) % self.cap

		# Iterate through the table to find the key
		for count in range(self.cap):
			if self.table[index] is None:
				return False

			if self.table[index] != self.tombstone and self.table[index][0] == key:
				# Update the value if the key is found and it's not a tombstone
				self.table[index] = (key, value)
				return True

			# Move to the next index
			index = (index + 1) % self.cap

		return False
	
	# This function removes a key-value pair from the hash table
    	# Parameters:
   	# 	key: the key to remove
    	# Returns:
    	# 	- True: if the key is removed successfully
	# 	- False: if the key does not exist
	def remove(self, key):
		index = hash(key) % self.cap

		for count in range(self.cap):
			if self.table[index] is None:
				return False
				
			if self.table[index] != self.tombstone and self.table[index][0] == key:
				# Replace with tombstone 
				self.table[index] = self.tombstone
				# Decrement the hash table size
				self.size -= 1
				return True

			# Move to the next index
			index = (index + 1) % self.cap

		return False

	# This function searches for a value with a given key
	# Parameters:
	# 	key: The key to search for
	# Returns:
	# 	- The value with the key when it is found
	# 	- If the key does not exist, return None
	def search(self, key):
		index = hash(key) % self.cap

		# Iterate through the table to find the key
		for count in range(self.cap):
			if self.table[index] is None:
				return None

			if self.table[index] != self.tombstone and self.table[index][0] == key:
				# Return the value if the key is found and it's not a tombstone
				return self.table[index][1]

			index = (index + 1) % self.cap

		return None

	# This function returns the current capacity of the hash table
    	# Returns:
	#	- The capacity of the table
	def capacity(self):
		return self.cap

	# This function returns the current capacity of the hash table
    	# Returns:
	#	- The size of the table (the number of stored elements)
	def __len__(self):
		return self.size

