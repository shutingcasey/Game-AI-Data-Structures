# Game Improvements

Put link to your video demonstrating your feature here.  See assignment specs on what is required for this component

https://seneca-my.sharepoint.com/personal/chsu17_myseneca_ca/_layouts/15/stream.aspx?id=%2Fpersonal%2Fchsu17%5Fmyseneca%5Fca%2FDocuments%2FDSA%20Assignment%202%2FDSA%20AS2%2Emp4&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJPbmVEcml2ZUZvckJ1c2luZXNzIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXciLCJyZWZlcnJhbFZpZXciOiJNeUZpbGVzTGlua0NvcHkifX0&ga=1&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E4bc5db68%2Dc6ca%2D49f9%2D81c4%2D4fcdda022926

# Main Author: Casey Hsu
# Main Reviewer: Hyeri Jang & Christine Ang
