#    Main Author(s): Hyeri Jang
#    Main Reviewer(s): Christine Ang, Shu-Ting Hsu




class SortedList:

	class Node:
		# Initializes a Node
		# Arguments:
		# 	data: The data stored in the node
		#	next: A reference to the next node in the list
		#	prev: A reference to the previous node in the list
		def __init__(self, data, next = None, prev = None):
			self.data = data
			self.next = next
			self.prev = prev

		# Returns the data stored in the node
		def get_data(self):
			return self.data

		# Returns the next node in the list
		def get_next(self):
			return self.next

		# Returns the previous node in the list
		def get_previous(self):
			return self.prev

	# Initializes an empty list with sentinel nodes
	# Dummy nodes are placed before the first actual node and after the last actual node
	def __init__(self):
		self.front = self.Node(None) 
		self.back = self.Node(None)
		self.front.next = self.back
		self.back.prev = self.front

	# Returns the first actual node or None when it is empty
	def get_front(self):
		if self.is_empty():
			return None
		else:
			return self.front.next # The actual first node

	# Returns the last actual node or None when it is empty
	def get_back(self):
		if self.is_empty():
			return None
		else:
			return self.back.prev # The actual last node

	# Checks whether the list is empty
	# Returns True if it is empty
	def is_empty(self):
		return self.front.next == self.back

	# Returns the length of the list
	def __len__(self):
		count = 0
		curr = self.front.next
		
		# Loop through the list and count the number of nodes in the list
		while curr != self.back: 
			count += 1
			curr = curr.next

		return count

	# Inserts a new node with the data into the list
	# Arguments:
	# 	data: The data to be inserted into the list
	# Returns:
	#	The newly inserted node
	def insert(self, data):
		curr = self.front.next # The first actual node

		# Loop through the list to find the correct position to insert the data
		while curr != self.back:
			# If the new data is less than or equal to the current node's data
			if data <= curr.data:
				prev_node = curr.prev            
				next_node = curr

				# Create the new node and insert it between prev_node and next_node
				new_node = self.Node(data, next_node, prev_node)
				prev_node.next = new_node 
				next_node.prev = new_node 

				return new_node	
			# Move to the next node if the position is not yet found
			curr = curr.next 

		# If the new data is greater than all existing elements insert it at the end
		prev_node = self.back.prev 
		next_node = self.back 

		# Create the new node and insert it before the back sentinel
		new_node = self.Node(data, next_node, prev_node)
		prev_node.next = new_node 
		next_node.prev = new_node 

		return new_node

	# Removes the specific node from the list
	# Arguments:
	#	node: The node to be removed
	# Raises:
	#	ValueError: If the node referred to by Node
	def erase(self, node):
		if node == None:
			raise ValueError('Cannot erase node referred to by None')
		
		curr = self.front.next # The first actual node

		# Loop through the list to find the node to remove
		while curr != self.back:
			# If the current node matches the node to be deleted
			if curr == node: 
				# Update pointers to skip over the current node
				curr.prev.next = curr.next
				curr.next.prev = curr.prev
				del curr # Delete the node
				return 
			curr = curr.next # Move to the next node

	# Search for the node containing the specific data
	# Arguments:
	#	- data: The data to search for in the list
	# Returns:
	#	the node contatinig the data or Node if no node is found
	def search(self, data):
		target = None
		curr = self.front.next # The first actual node

		# Loop through the list to find the node containing the target data
		while curr != self.back:
			# If the current node contains the target data
			if curr.data == data: 
				target = curr # Mark the target node
				break 
			curr = curr.next 

		return target

